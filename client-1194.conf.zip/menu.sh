#!/bin/bash
#Menu 
echo -e "
echo -e "                 __   _,--="=--,_"
echo -e "                /  \."    .-.    "./  \"
echo -e "               /  ,/  _   : :   _  \/` \"
echo -e "               \  `| /o\  :_:  /o\ |\__/"
echo -e "                `-'| :="~` _ `~"=: | "
echo -e "                   \`     (_)     `/"
echo -e "            .-"-.   \      |      /   .-"-."
echo -e "      .----{     }--|  /,.-'-.,\  |--{     }----"
echo -e "       )   (_)_)_)  \_/`~-===-~`\_/  (_(_(_)   ("
echo -e " (|SELAMAT DATANG DI VPS PHREAKER'S JATENG OFFICIAL|)"
echo -e "  )#Admin : Pa'an Finest   |Admin : Imron Sya'faat#("
echo -e " ( #Admin : Affan Fattahila|Admin : Said Ramadhan # )"
echo -e "  )#Admin : Vicky Bramasta |Admin : Aji KA        #("
echo -e " '------------------------------------------------'

echo -e "1.)menu (Menampilkan Daftar Perintah)"   echo -e "9.)speedtest (Speedtest VPS)
echo -e "2.)usernew (Membuat Akun SSH & OpenVPN)  echo -e "10.)reboot (Reboot VPS)
echo -e "3.)trial (Membuat Akun Trial)"           echo -e "11.)info (Menampilkan Informasi Sistem"
echo -e "4.)hapus (Menghapus Akun SSH & OpenVPN)" echo -e "12.)exit
echo -e "5.)cek (Cek User Login)"
echo -e "6.)member (Cek Member SSH & OpenVPN)"
echo -e "7.)expired (Cek User SSH & OpenVPN)"
echo -e "8.)resvis  (Restart Service Dropbear, Webmin Squid3, OpenVPN & SSH)" 